import pygame
import Tiles
import Enemies
import Player
import TextRender
import Level_1

WIDTH = 1920
HEIGHT = 1080


def _map_create(_map):
    """ Create level platforms """
    x = 0
    y = 0
    w = 0 # width of level
    h = 0 # height of level (if needed for a top boundary)
    loop = 0
    inc = 70

    #Get the size of the map
    for string in _map.level:
        w = len(string)
        h = len(_map.level)
        break
    
    for string in _map.level:
        x = 0
        if loop > 0:
            y += inc
        for letter in string:
            loop +=1
            if letter == ' ':
                x += inc
                continue
            else:
                if letter == 'X':
                    _map.platforms.add(_map.x(x,y))
                elif letter == 'G':
                    _map.platforms.add(_map.g(x,y))
                elif letter == 'N':
                    _map.platforms.add(_map.n(x,y))
                elif letter == 'B':
                    _map.platforms.add(_map.b(x,y))
                elif letter == 'H':
                    _map.platforms.add(_map.h(x,y))
                elif letter == 'M':
                    _map.platforms.add(_map.m(x,y))
                elif letter == 'L':
                    _map.platforms.add(_map.l(x,y))
                elif letter == 'R':
                    _map.platforms.add(_map.r(x,y))
                elif letter == 'C':
                    _map.platforms.add(_map.c(x,y))
                elif letter == 'W':
                    _map.platforms.add(_map.w(x,y))
                elif letter == 'Y':
                    _map.platforms.add(_map.y(x,y))
                elif letter == 'Z':
                    _map.platforms.add(_map.z(x,y))
                elif letter == 'P':
                    player = _map.p(x,y)
                    player.level_start = (x,y)
                    _map.player = player
        
                x += inc

    _map.platforms.add(Level_1.Boundary(0,0,HEIGHT),
                       Level_1.Boundary(w*inc-1,0,HEIGHT))
    _map.width = w*inc
    
    
            
class Level_2(object):
    """ Define Level 2 """
    def __init__(self):
        self.x = Tiles.StoneCenter   
        self.g = Tiles.StoneMid
        self.n = Tiles.StoneCenter_Rounded

        self.l = Tiles.StoneCliffLeft
        self.r = Tiles.StoneCliffRight
        self.c = Tiles.StoneLeft

        self.b = Tiles.StoneRight
        self.h = Tiles.WaterFill
        self.m = Tiles.SwitchMid
        
        self.w = Tiles.LiquidWaterTop_Mid
        self.y = Tiles.RedGem
        self.z = Tiles.BlueGem
        

        self.p = Player.Player

        
        self.level = ['                            ',
                      '                            ',
                      '  GGGGGGR  LGGR           N ',
                      'CGXXXXX         LR      LR  ',
                      '          Z          G      ',
                      '         LGWWWGGGR      GG  ',
                      'GG        XHHHX   N N  N   N', 
                      'X G                       G ',
                      'X            Y Y      NLGGG ',
                      'XR     CGGGGGGGGGGGR Z  XXX ',
                      '   N  GX             N      ',    
                      'P    GX                     ',
                      'GGGGGGGGWWWWWWWCGGGGGGGGGGG ',
                      'XXXXXXXXHHHHHHHXXXXXXXXXXXX ',
                      'XXXXXXXXGGHHHCGXXXXXXXXXXXX ',
                      'XXXXXGGGXXGGGGXXXXXXXXXXGGG ']
        
        self.objective = TextRender.Text("Get a score of 100!",800,200)
        self.background = pygame.image.load("cave_01.png").convert()
        self.background = pygame.transform.scale(self.background,(WIDTH,HEIGHT))        
        self.platforms = pygame.sprite.LayeredUpdates()
        self.enemies = pygame.sprite.Group()
        self.player = None

        # Additional platforms that need precise control
        self.switch1 = self.m(600,560)
        self.lift1 = Tiles.Lift(530,610,100)
        

        self.platforms.add(self.switch1, self.lift1)

        # Enemies
        fish1 = Enemies.Fish(700, 940)
        fish2 = Enemies.Fish(765, 420)
        snail1 = Enemies.Snail(140,140)
        snail2 = Enemies.Snail(840,630)
        

        
        self.platforms.add(fish1,fish2,snail1,snail2)
        self.enemies.add(fish1,fish2,snail1,snail2)

    def update(self):
        """ Provides a way to script actions within the level and precisely control
            objects.
            Can also be used to test for level objectives being complete"""
        # Script level objectives 
        if self.player.score >= 100:
            self.player.level_complete = True
            
        if self.switch1.state == 1:
            if self.lift1.pos < self.lift1.height: # move up
                self.lift1.rect.y -= 2
                self.lift1.pos += 2
        else:
            if self.lift1.pos > 0: # move down
                self.lift1.rect.y += 2
                self.lift1.pos -= 2
        

class Level_3(object):
    
    def __init__(self):

        self.l = Tiles.CastleLeft
        self.r = Tiles.CastleRight
        self.x = Tiles.CastleMid
        self.n = Tiles.Castle
        self.c = Tiles.CastleCenter

        self.p = Player.Player

        self.level = [
            '                            ',
            '                            ',
            '  P        N                ',
            'LXXXXXXXXXR  N  LXXXXXXXXR  ',
            '      C                     ',
            '      C                     ',
            '      C    LXXR             ',
            '      C                     ',
            'LX  XXXXXXXXXXXXXXXXXR     N',
            '      XXX                  N',
            'XXX    XX                XXX',
            '            N  XXXXXXXXX XXX',
            '         N                  ',
            'XXXXXXXXXXXX                ',
            'CCCCCCCCCCCCXXXXXXXXXXXXXXXX',
            'CCCCCXXXCCCCCCCCCCCCCCCCCCCC']


        self.background = pygame.image.load("platformerGraphicsDeluxe_Updated/bg_castle.png").convert()
        self.background = pygame.transform.scale(self.background,(WIDTH,HEIGHT))  
        self.player = None

        self.platforms = pygame.sprite.LayeredUpdates()
        self.enemies = pygame.sprite.Group()

    def update(self):
        return

    
