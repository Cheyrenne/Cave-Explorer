import pygame
import time

pygame.init()

# constants
WIDTH = 1920
HEIGHT =  1080

# initialize the game screen
screen = pygame.display.set_mode([WIDTH,HEIGHT],pygame.FULLSCREEN)
pygame.display.set_caption("Cave Explorer")

import Levels
import Level_1
import Player
import Healthbar
import TextRender

next_level = 1
level_num = 0

# add first level sprites
sprite_list = pygame.sprite.LayeredUpdates()
player = Player.Player(1400,200)
health_bar = Healthbar.HealthBar()
level = Level_1.Level01(WIDTH, HEIGHT)

# Populate sprite list with platforms
sprite_list.add(level.platforms)
player.block_list = sprite_list
sprite_list.add(health_bar)

# Add all levels to the level list
level_list = []
level_list.append(Levels.Level_2())
level_list.append(Levels.Level_3())


# Initialize game clock
clock = pygame.time.Clock()
start = time.clock()
end = 0

done = False

# --------- Main Loop --------------
while not done:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                done = True
            elif event.key == pygame.K_SPACE:
                player.move_up()
            elif event.key == pygame.K_f:
                player.interact()
            
    keys = pygame.key.get_pressed()
    if keys[pygame.K_a]:
        player.move_left()
    if keys[pygame.K_d]:
        player.move_right()

    # Call updates
    player.update()
    # If dead, restart at start of the level
    if player.health <= 0:
        time.sleep(3)
        player.rect.topleft = player.level_start
        player.health = 75
    health_bar.update(player.health)
    level.enemies.update(player)
    level.update()

    # Draw everything to screen
    screen.blit(level.background,[0,0])
    sprite_list.draw(screen)
    screen.blit(player.image,player.rect.topleft)
    
    #Display level objective for 5 seconds
    if (end - start) < 3:
        end = time.clock()
        screen.blit(level.objective.txt,(level.objective.x,level.objective.y))

    # load next level
    if player.level_complete:
        # completed last level, end game
        if next_level > len(level_list):
            done = True
            text = TextRender.Text("You finished the Game!",900,200)
            TextRender.draw_text(text)
        else:
            old_level = level
            level_num = next_level            
            level = level_list[level_num-1]
            Levels._map_create(level)
            next_level += 1

            # Get rid of old sprites
            for s in old_level.platforms:
                s.kill()
            player.kill()
            
            sprite_list.add(level.platforms)
            player = level.player
            player.block_list = sprite_list
            time.sleep(1)
        
    # Display refreshed screen
    pygame.display.flip()
    clock.tick(30)
    
pygame.quit()

