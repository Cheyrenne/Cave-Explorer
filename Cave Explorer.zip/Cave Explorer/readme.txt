Installation:

Software Requirements:

Python 3.3.5 (32 bit) 
https://www.python.org/downloads/release/python-335/
Click on Windows x86 MSI Installer


Pygame 1.9.2a (32 bit)
https://bitbucket.org/pygame/pygame/downloads
Click on pygame-1.9.2a0.win32-py3.2.msi


OS: Windows 7 64-bit
Monitor res: 1920 x 1080

Download the Game files in the same structure they are in the folder.
Run the game by using GameOmega.bat file

Links to source code files and tutorials can be found at: https://github.com/Cheyrenne


Imported Modules: Pygame

Resources used:

1.	Link : http://programarcadegames.com/python_examples/show_file.php?file=move_with_walls_example.py

	This link is to a video tutorial and code about how to detect collisions with your
	player sprite in pygame. I modified the collision code to include gravity in my 	version.

2.	Platformer with Spritesheets
	
    	Link: http://programarcadegames.com/python_examples/sprite_sheets/

	I used this to learn how to go about making and laying out file/class structures for a platformer from scratch. 

3. 	OpenGameArt
	Link: opengameart.org

	This site has lots of public domain artwork. All of the art for the game came from the site.
	For the 2nd and 3rd level, most of the art came from the PlatformerArt Pack from the 
	submitter Kenney. They can be found by searching "Kenney" in submitter field.
	
