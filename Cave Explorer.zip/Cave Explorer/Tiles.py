import pygame
import time


class Castle(pygame.sprite.Sprite):
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Tiles/castle.png").convert_alpha()
    def __init__(self,x,y,):
            self._layer = 1
            pygame.sprite.Sprite.__init__(self)
            self.image = Castle.image
            self.rect = self.image.get_rect()
            self.rect.topleft = [x,y]

class CastleCenter(pygame.sprite.Sprite):
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Tiles/castleCenter.png").convert_alpha()
    def __init__(self,x,y,):
            self._layer = 1
            pygame.sprite.Sprite.__init__(self)
            self.image = CastleCenter.image
            self.rect = self.image.get_rect()
            self.rect.topleft = [x,y]

class CastleMid(pygame.sprite.Sprite):
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Tiles/castleMid.png").convert_alpha()
    def __init__(self,x,y,):
            self._layer = 1
            pygame.sprite.Sprite.__init__(self)
            self.image = CastleMid.image
            self.rect = self.image.get_rect()
            self.rect.topleft = [x,y]

class CastleLeft(pygame.sprite.Sprite):
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Tiles/castleLeft.png").convert_alpha()
    def __init__(self,x,y,):
            self._layer = 1
            pygame.sprite.Sprite.__init__(self)
            self.image = CastleLeft.image
            self.rect = self.image.get_rect()
            self.rect.topleft = [x,y]

class CastleRight(pygame.sprite.Sprite):
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Tiles/castleRight.png").convert_alpha()
    def __init__(self,x,y,):
            self._layer = 1
            pygame.sprite.Sprite.__init__(self)
            self.image = CastleRight.image
            self.rect = self.image.get_rect()
            self.rect.topleft = [x,y]

class BlueGem(pygame.sprite.Sprite):
    """ Blue Gem """
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Items/gemBlue.png").convert_alpha()
    def __init__(self,x,y,):
        self._layer = 1
        pygame.sprite.Sprite.__init__(self)
        self.score = 50
        self.image = BlueGem.image
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]

class YellowGem(pygame.sprite.Sprite):
    """ Yellow Gem """
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Items/gemYellow.png").convert_alpha()
    def __init__(self,x,y,):
        self._layer = 1
        pygame.sprite.Sprite.__init__(self)
        self.score = 30
        self.image = YellowGem.image
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]

class RedGem(pygame.sprite.Sprite):
    """ Red Gem """
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Items/gemRed.png").convert_alpha()
    def __init__(self,x,y,):
        self._layer = 1
        pygame.sprite.Sprite.__init__(self)
        self.score = 15
        self.image = RedGem.image
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]


class SwitchMid(pygame.sprite.Sprite):
    """ Center Switch Tile """
    # Class wide definitions
    images = [pygame.image.load("platformerGraphicsDeluxe_Updated/Items/switchMid.png").convert_alpha(),
              pygame.image.load("platformerGraphicsDeluxe_Updated/Items/switchLeft.png").convert_alpha()
              ]

    def __init__(self,x,y,):
        self._layer = 1
        pygame.sprite.Sprite.__init__(self)
        self.state = 0
        self.image = SwitchMid.images[self.state]
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]
        self.platform = None

    def update(self):
        if self.state is 0:
            self.state = 1
        elif self.state is 1:
            self.state = 0
        self.image = SwitchMid.images[self.state]


class Lift(pygame.sprite.Sprite):
    """ Bridge Tile """
    # Class wide definitions
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Tiles/bridge_half.png").convert_alpha()
    
    def __init__(self,x,y,height):
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)
        self.image = Lift.image
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]
        self.height = height
        self.pos = 0

    

class RockHillLeft(pygame.sprite.Sprite):
    """ Rock Hill Left Tile """
    # Class wide definitions
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Tiles/rockHillLeft.png").convert_alpha()
    def __init__(self,x,y):
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)
        self.image = RockHillLeft.image
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]


class LightShaft(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("GameImages/cave_shaft_light_1.png").convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.topleft = [x, y]
        
class Health(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("GameImages/hud_heartFull.png").convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.bottomleft = [x,y]

class WaterTile(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load("GameImages/water_2.png").convert_alpha()
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]


class StoneCenter(pygame.sprite.Sprite):
    """ Stone Center Tile """
    # Class wide definitions
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Tiles/stoneCenter.png").convert_alpha()
    
    def __init__(self,x,y):
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)
        self.image = StoneCenter.image
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]

class StoneMid(pygame.sprite.Sprite):
    """ Stone Mid Tile """
    # Class wide definitions
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Tiles/stoneMid.png").convert_alpha()
    
    def __init__(self,x,y):
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)
        self.image = StoneMid.image
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]

class StoneCenter_Rounded(pygame.sprite.Sprite):
    """ Stone Center Rounded Tile """
    # Class wide definitions
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Tiles/stoneCenter_rounded.png").convert_alpha()
    
    def __init__(self,x,y):
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)
        self.image = StoneCenter_Rounded.image
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]

class StoneCliffLeft(pygame.sprite.Sprite):
    """ Stone Cliff Left Tile """
    # Class wide definitions
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Tiles/stoneCliffLeft.png").convert_alpha()
    
    def __init__(self,x,y):
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)
        self.image = StoneCliffLeft.image
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]

class StoneCliffRight(pygame.sprite.Sprite):
    """ Stone Cliff Right Tile """
    # Class wide definitions
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Tiles/stoneCliffRight.png").convert_alpha()
    
    def __init__(self,x,y):
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)
        self.image = StoneCliffRight.image
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]

class StoneLeft(pygame.sprite.Sprite):
    """ Stone Cliff Right Tile """
    # Class wide definitions
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Tiles/stoneLeft.png").convert_alpha()
    
    def __init__(self,x,y):
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)
        self.image = StoneLeft.image
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]

class StoneRight(pygame.sprite.Sprite):
    """ Stone Cliff Right Tile """
    # Class wide definitions
    image = pygame.image.load("platformerGraphicsDeluxe_Updated/Tiles/stoneRight.png").convert_alpha()
    
    def __init__(self,x,y):
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)
        self.image = StoneRight.image
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]


class LiquidWaterTop_Mid(pygame.sprite.Sprite):
    """ Liquid Water Top Mid Tile """
    # Class wide definitions
    image = pygame.image.load("GameImages/water_2.png").convert_alpha()
    
    def __init__(self,x,y):
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)
        self.image = LiquidWaterTop_Mid.image
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y]

class WaterFill(pygame.sprite.Sprite):
    image = pygame.Surface( [70,95])
    image.fill( [162, 231, 238] )
        
    def __init__(self,x,y):
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)
        self.rect = self.image.get_rect()
        self.rect.topleft = [x,y-25]

        
class Tile (pygame.sprite.Sprite):
    """ Create tile object """
    
    def __init__(self,x,y,image):
        self.x = x
        self.y = y
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.image.load(image)#.convert()
        
        # make top left corner the location passed in
        self.rect = self.image.get_rect()
        self.rect.topleft = [self.x,self.y]
