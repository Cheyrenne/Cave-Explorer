import pygame

class Fish(pygame.sprite.Sprite):
    """ Fish Enemy """
    frames = [pygame.image.load("platformerGraphicsDeluxe_Updated/Enemies/fishSwim1_right.png").convert_alpha(),
              pygame.image.load("platformerGraphicsDeluxe_Updated/Enemies/fishSwim2_right.png").convert_alpha(),
              pygame.image.load("platformerGraphicsDeluxe_Updated/Enemies/fishSwim1.png").convert_alpha(),
              pygame.image.load("platformerGraphicsDeluxe_Updated/Enemies/fishSwim2.png").convert_alpha(),
             ]
    roam_dist = 150
    damage = 25
    def __init__(self,x,y):

        self._layer = 1  
        pygame.sprite.Sprite.__init__(self)
        self.image = Fish.frames[0]
        self.rect = self.image.get_rect()
        self.rect.bottomleft = [x,y]
        self.x_change = 0
        self.move_left = False
        self.frame = 0
        self.count = 0

    def update(self,player):
        # Move right
        if self.move_left is False:
            self.x_change += 1
            self.rect.x += 1
            if self.count == 0 or self.count == 1:
                self.image = Fish.frames[0]
            elif self.count == 2 or self.count == 3:
                self.image = Fish.frames[1]
            self.count += 1
            if self.count == 4:
                self.count = 0
            if self.x_change >= Fish.roam_dist:
                self.move_left = True
                self.count = 0
        # Move left
        else:
            self.x_change -= 1
            self.rect.x -= 1
            if self.count == 0 or self.count == 1:
                self.image = Fish.frames[2]
            elif self.count == 2 or self.count == 3:
                self.image = Fish.frames[3]
            self.count += 1
            if self.count == 4:
                self.count = 0
            if self.x_change <= 0:
                self.move_left = False
                self.count = 0
            
        

class Snail(pygame.sprite.Sprite):
    """ Snail Enemy """
    image_Left1 = pygame.image.load("platformerGraphicsDeluxe_Updated/Enemies/snailWalk1.png").convert_alpha()
    image_Left2 = pygame.image.load("platformerGraphicsDeluxe_Updated/Enemies/snailWalk2.png").convert_alpha()
    roam_dist = 250

    kill_image = pygame.image.load("platformerGraphicsDeluxe_Updated/Enemies/snailShell.png").convert_alpha()
    damage = 25
    
    def __init__(self,x,y):
        self._layer = 1
        pygame.sprite.Sprite.__init__(self)
        self.image = Snail.image_Left1
        self.rect = self.image.get_rect()
        self.rect.bottomleft = [x,y]
        self.x_change = 0
        self.move_left = False
        self.frame = 0
        self.count = 0
        
    def update(self,player):
        # Move right
        if self.move_left is False: 
            self.x_change += 1
            self.rect.x += 1
            if self.x_change == Snail.roam_dist:
                self.move_left = True
        # Move left
        else:
            if self.frame == 0 :
                self.image = Snail.image_Left1
                self.frame += 1
            elif self.frame == 1:
                self.image = Snail.image_Left2
                self.frame = 0
                
            if self.count == 0:    
                self.x_change -= 1
                self.rect.x -= 1
                self.count += 1
            else:
                self.count -= 1
            
            if self.x_change == 0:
                self.move_left = False
                
        # Check if colliding with player
        if pygame.sprite.collide_rect(self,player):
            if self.rect.top == player.rect.bottom:
                self.image = Snail.kill_image
                self.kill()
            else:
                player.take_damage(Snail.damage)
                
            

    
        
        
            
