import pygame

class Text(object):
    """ Create a text object """
    def __init__(self,text,x, y):
        font = pygame.font.Font(None, 50)
        self.txt = font.render(text,True,[255,255,255])
        self.x = x
        self.y = y

def draw_text(text):
    """ Print text to the screen """
    surface = pygame.display.get_surface()
    surface.blit(text.txt, (text.x, text.y))

