import pygame
import TextRender
import Tiles

class Platform(pygame.sprite.Sprite):
    def __init__(self,x,y,image):
        self.x = x
        self.y = y
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)

        # load ground tile
        self.image = pygame.image.load(image).convert_alpha()
        self.image.set_colorkey([0,0,0])
        
        # make top left corner the location passed in
        self.rect = self.image.get_rect()
        self.rect.topleft = [self.x,self.y]

class Boundary(pygame.sprite.Sprite):
    def __init__(self, x, y, h):
        pygame.sprite.Sprite.__init__(self)
        
        # Make a 1 x h white surface and set white to be
        # transparent when rendered
        self.image = pygame.Surface((1, h))
        self.image.fill([255, 255, 255])
        #self.image.set_colorkey([255, 255, 255])

        # Position boundary's top left corner
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)

class Level(object):
   
    def __init__(self):
        self.sprites = None
        self.platforms = pygame.sprite.LayeredUpdates()
        self.gravity = 10  # default fall rate
        self.background = pygame.image.load("cave_01.png").convert()
        self.objective = None
        self.enemies = pygame.sprite.Group()
        
    def update(self):
        return
        

    

class Level01(Level):
    def __init__(self, w, h):
        Level.__init__(self)
        
        # Ground / Ceiling Tiles 
        gr = "cave_gr_tile_tex_1.png"
        plat1 = Platform(0,900,gr)
        plat2 = Platform(600,900,gr)
        self.platforms.add(plat1,plat2)

        top = "GameImages/cave_top_1b_z1_small.png"
        top_bg= "GameImages/cave_gr_tile_horiz_large2x.png"
        for y in range(0, 1920,600):
            self.platforms.add(Platform(y,0,top_bg))
        for x in range(0,1920,188):
            self.platforms.add(Platform(x,0,top))

        # Water Tiles
        for x in range(1200,1920+70,70):
            tile = Tiles.WaterTile(x,900)
            self.platforms.add(tile)

        pygame.sprite.Sprite.__init__(tile)
        tile.rect = tile.image.get_rect()
        tile.rect.topleft = [1200, 945]     
        tile.image = pygame.Surface( [720,135])
        
        tile.image.fill( [162, 231, 238] )

        

        # Platforms (Non-Ground)
        img = "GameImages/cave_gr_platform_2.png"
        plat1 = Platform(500,800,img)
        plat2 = Platform(757, 650, img)
        plat3 = Platform(980, 675, img)
        plat4 = Platform(1125, 575, img)
        plat5 = Platform(1170, 275,img)
        plat6 = Platform(950, 300,img)
        self.platforms.add(plat1,plat2,plat3,plat4,plat5,plat6)

        img = "GameImages/cave_platform_2.png"
        plat1 = Platform(100,300, img)

        img = "GameImages/cave_big_platform_1.png"
        plat2 = Platform(1920 - 610, 515,img)

        self.platforms.add(plat1,plat2)
        
        # Scale background image
        self.background = pygame.transform.scale(self.background,(w, h))

        # Level items
        health_pack1 = Tiles.Health(1050, 670)
        self.platforms.add(health_pack1)

        # Exit
        plat1= Tiles.LightShaft(1920 - 360,75)
        plat1.image = pygame.transform.scale(plat1.image,(300,525))
        self.platforms.add(plat1)

        self.objective = TextRender.Text("Go into the light!",925,200)

        # Make left and right level boundaries
        self.left_bound = Boundary(0,0,h)
        self.platforms.add(self.left_bound)
        
        self.right_bound = Boundary(w-1,0,h)
        self.platforms.add(self.right_bound)
