class HealthBar(pygame.sprite.Sprite):
    def __init__(self):
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)

        self.image = pygame.Surface([200, 10])
        #self.image.fill([0,0,0])
        self.rect = self.image.get_rect()
        self.rect.topleft = [20,120]
 

    def update(self, health):
        fill = health / 100 * 200
        self.image = pygame.Surface([fill,10])
        self.image.fill([0,255,0])
        #empty = 200 - fill
        #self.image.fill([0,0,0],pygame.Rect(20+fill,120,empty,10))
