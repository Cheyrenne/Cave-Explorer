import pygame
import Tiles
import TextRender

class Player(pygame.sprite.Sprite):
    """ Player object """
    def __init__(self,x,y):
        self._layer = 0
        pygame.sprite.Sprite.__init__(self)
        self.speed = 0
        self.y_velocity = 0
        
        self.x_change = 0
        self.y_change = 0
        self.is_jumping = False
        self.action = False

        self.health = 75
        self.swim = False
        self.block_list = None
        self.level_complete = False
        self.level_start = (0,0)
        self.score = 0

        # Load character image
        # use convert_alpha() for file types with transparency like .png
        self.image = pygame.image.load("characters/p2_walk01.png").convert_alpha() 
        self.rect = self.image.get_rect()
        
        # top left corner is (x,y)
        self.rect.topleft = [x,y]

    def update(self):
        
        # Check for left/right collisions
        collide_list = pygame.sprite.spritecollide(self,self.block_list,False)
        for block in collide_list:
            if isinstance(block,Tiles.Health):
                self.health += 50
                if self.health > 100:
                    self.health = 100
                block.kill()
            elif isinstance(block,Tiles.RedGem):
                self.score += block.score
                block.kill()
                
            elif isinstance(block,Tiles.BlueGem):
                self.score += block.score
                block.kill()
                
            elif isinstance(block,Tiles.LiquidWaterTop_Mid):
                if self.swim is False:
                    self.health = 0
                else:
                    if self.y_velocity >= 0 and self.is_jumping is False:
                        self.rect.bottom = block.rect.top
                        self.is_jumping = False
                        self.y_velocity = 0
                    elif self.rect.top < block.rect.bottom and self.y_velocity < 0:
                        self.rect.top = block.rect.bottom
                        self.y_velocity = 0
                        
            elif isinstance(block,Tiles.SwitchMid):
                if self.action is True:
                    block.update()
                    self.action = False
                    
            elif isinstance(block,Tiles.LightShaft):
                if self.action is True:
                    self.level_complete = True
            else:
                if self.x_change > 0:
                    self.rect.right = block.rect.left
                else:
                    self.rect.left = block.rect.right
        self.x_change = 0
    
        # Calculate effect of gravity
        self.y_velocity = self.y_velocity + 6
        self.rect.y += self.y_velocity + 1/2 * 6

        if self.y_velocity >= 0:
            self.is_jumping = False #falling
        
        # Check for up/down collisions
        collide_list = pygame.sprite.spritecollide(self,self.block_list,False)
        for block in collide_list:
            
            if isinstance(block,Tiles.Health):
                self.health += 50
                if self.health > 100:
                    self.health = 100
                    block.kill()
                    
            elif isinstance(block,Tiles.RedGem):
                self.score += block.score
                block.kill()
                
            elif isinstance(block,Tiles.BlueGem):
                self.score += block.score
                block.kill()
                
            elif isinstance(block,Tiles.LiquidWaterTop_Mid):
                if self.swim is False:
                    self.health = 0
                else:
                    if self.y_velocity >= 0 and self.is_jumping is False:
                        self.rect.bottom = block.rect.top
                        self.is_jumping = False
                        self.y_velocity = 0
                    elif self.rect.top < block.rect.bottom and self.y_velocity < 0:
                        self.rect.top = block.rect.bottom
                        self.y_velocity = 0
                        
            elif isinstance(block,Tiles.SwitchMid):
                if self.action is True:
                    block.update()
                    self.action = False
                    
            elif isinstance(block,Tiles.LightShaft):
                if self.action is True:
                    self.level_complete = True
            else:
                if self.y_velocity >= 0 and self.is_jumping is False:
                    self.rect.bottom = block.rect.top
                    self.is_jumping = False
                    self.y_velocity = 0
                elif self.rect.top < block.rect.bottom and self.y_velocity < 0:
                    self.rect.top = block.rect.bottom
                    self.y_velocity = 0
        #self.y_change = 0
        self.action = False
            

    def gravity(self):
        self.rect.y += 10
        self.y_change += 1
        
        codllide_list = pygame.sprite.spritecollide(self,self.block_list,False)
        print(collide_list)
        # Checks if on top of some platform/ground
        if len(collide_list) > 0:
            for block in collide_list:
                self.rect.bottom = block.rect.top
            self.y_change = 0
        else:
            self.rect.y -= 10
            self.y_change += 1

    def is_on_ground(self):
        collide_list = pygame.sprite.spritecollide(self,self.block_list,False)
        for block in self.block_list:
            if (self.rect.bottom == block.rect.top):
                return True
            else:
                return False

            
    def move_up(self):
        # Check to see if on the ground. Have to move down a few pixels
        # or collide won't work
        self.rect.y += 1
        collide_list = pygame.sprite.spritecollide(self,self.block_list,False)
        self.rect.y -= 1
        for block in collide_list: 
            if self.rect.bottom == block.rect.top:
                self.y_velocity = 0
                self.y_velocity -= 5 + 50  
                self.y_change -= 1
                self.is_jumping = True
         
    def move_down(self):
        self.speed = 6
        self.y_change += 1
        self.rect.y += self.speed

    def move_left(self):
        self.speed = 6
        self.x_change -= 1
        self.rect.x -= self.speed

    def move_right(self):
        self.speed = 6
        self.x_change += 1
        self.rect.x += self.speed

    def interact(self):
        self.action = True

    def take_damage(self, damage):
        self.health -= damage
